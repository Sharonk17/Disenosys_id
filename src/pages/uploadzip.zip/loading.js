import Loader from "@/components/custom/Loader";

export default function Loading() {
  return <Loader/>;
}
